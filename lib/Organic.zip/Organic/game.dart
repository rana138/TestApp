import 'dart:async';
import 'dart:math';

import 'package:flutter/material.dart';

import 'dart:async';
import 'dart:math';

import 'package:flutter/material.dart';

void main() {
  runApp(MyApp());
}

class MyApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Snack Catcher',
      theme: ThemeData(
        primarySwatch: Colors.blue,
      ),
      home: HomeScreen(),
    );
  }
}

class HomeScreen extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Snack Catcher'),
      ),
      body: Center(
        child: ElevatedButton(
          onPressed: () {
            Navigator.push(
              context,
              MaterialPageRoute(builder: (context) => GameScreen()),
            );
          },
          child: Text('Start Game'),
        ),
      ),
    );
  }
}

class GameScreen extends StatefulWidget {
  @override
  _GameScreenState createState() => _GameScreenState();
}

class _GameScreenState extends State<GameScreen> {
  List<Widget> snacks = [];
  int score = 0;

  @override
  void initState() {
    super.initState();
    startGame();
  }

  void startGame() {
    Timer.periodic(Duration(seconds: 1), (Timer timer) {
      if (mounted) {
        setState(() {
          snacks.add(Snack());
        });
      }
    });

    Timer.periodic(Duration(milliseconds: 50), (Timer timer) {
      if (mounted) {
        setState(() {
          snacks.removeWhere((snack) => (snack as Snack).fall());
        });
      }
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Snack Catcher'),
      ),
      body: Stack(
        children: [
          Container(
            decoration: BoxDecoration(
              image: DecorationImage(
                image: AssetImage('assets/background.jpg'),
                fit: BoxFit.cover,
              ),
            ),
          ),
          Column(
            children: [
              Expanded(
                flex: 9,
                child: Stack(
                  children: snacks,
                ),
              ),
              Expanded(
                flex: 1,
                child: Container(
                  color: Colors.black,
                  child: Center(
                    child: Text(
                      'Score: $score',
                      style: TextStyle(
                        color: Colors.white,
                        fontSize: 20,
                      ),
                    ),
                  ),
                ),
              ),
            ],
          ),
        ],
      ),
    );
  }
}

class Snack extends StatefulWidget {
  @override
  _SnackState createState() => _SnackState();

  fall() {}
}

class _SnackState extends State<Snack> {
  double position = 0;
  bool isCaught = false;

  int score = 0;

  @override
  void initState() {
    super.initState();
    position = Random().nextDouble();
  }

  @override
  Widget build(BuildContext context) {
    return AnimatedPositioned(
      duration: Duration(milliseconds: 500),
      top: isCaught
          ? MediaQuery.of(context).size.height
          : position * MediaQuery.of(context).size.height,
      left: Random().nextDouble() * MediaQuery.of(context).size.width,
      child: Draggable(
        child: Image.asset(
          'assets/snack.png',
          width: 50,
          height: 50,
        ),
        feedback: Image.asset(
          'assets/snack.png',
          width: 50,
          height: 50,
        ),
        onDragEnd: (details) {
          setState(() {
            if (!isCaught) {
              position = Random().nextDouble();
            }
          });
        },
        onDraggableCanceled: (velocity, offset) {
          setState(() {
            isCaught = true;
            _addToScore();
          });
        },
      ),
    );
  }

  bool fall() {
    if (position < 1.0 && !isCaught) {
      setState(() {
        position += 0.02;
      });
      return false;
    } else {
      return true;
    }
  }

  void _addToScore() {
    setState(() {
      // You can adjust the scoring logic based on your game design

      score += 10;
    });
  }
}
