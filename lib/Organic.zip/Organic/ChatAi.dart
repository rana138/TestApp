import 'package:flutter/material.dart';
import 'package:flutter/src/foundation/key.dart';
import 'package:flutter/src/widgets/framework.dart';

class ChatAi extends StatefulWidget {
  const ChatAi({Key? key}) : super(key: key);

  @override
  State<ChatAi> createState() => _ChatAiState();
}

class _ChatAiState extends State<ChatAi> {
  bool isExpanded = false;
  bool isClicked1 = false;
  bool isClicked2 = false;
  bool isKeyboardOpen = false;
  FocusNode _focusNode = FocusNode();

  String des =
      "Welcome to Flavorly, \n\nExplore the art of flavor with Flavorly's smart insights, turning ordinary meals into extraordinary delights. Flavorly is your sous chef, inspiring you with innovative ideas and delectable combinations.Unleash the potential of your pantry by simply entering ingredients or dish names into Flavorly's intuitive interface. From there, our AI magic begins, crafting personalized recipe suggestions tailored to your taste buds. Whether you're a seasoned chef or a kitchen novice, Flavorly is your sous chef, inspiring you with innovative ideas and delectable combinations. tart your journey with Flavorly and discover the joy of creating mouthwatering masterpieces at every meal. \nFeel free to customize and expand upon these lines to suit the specific features!";

  @override
  void initState() {
    super.initState();

    // Add a listener to check the focus state of the TextField
    _focusNode.addListener(() {
      setState(() {
        isKeyboardOpen = _focusNode.hasFocus;
      });
    });
  }

  @override
  Widget build(BuildContext context) {
    return WillPopScope(
      onWillPop: () async {
        return true;
      },
      child: Scaffold(
        appBar: AppBar(
          flexibleSpace: Container(
              decoration: BoxDecoration(
            color: Color.fromARGB(194, 202, 245, 203),
          )),
          toolbarHeight: 1,
          elevation: 0,
        ),
        body: Container(
          width: MediaQuery.of(context).size.width,
          height: MediaQuery.of(context).size.height,
          decoration: BoxDecoration(
            color: Color.fromARGB(194, 202, 245, 203),
          ),
          child: Stack(
            children: [
              Positioned(
                top: 15,
                left: 15,
                child: Row(
                  children: [
                    GestureDetector(
                      onTap: () {
                        Navigator.pop(context);
                      },
                      child: Container(
                          padding: EdgeInsets.all(8),
                          decoration: BoxDecoration(
                            borderRadius: BorderRadius.circular(100),
                            color: Color.fromARGB(255, 39, 120, 42),
                          ),
                          child: Icon(
                            Icons.arrow_back_ios,
                            color: Colors.white,
                          )),
                    ),
                    SizedBox(
                      width: 10,
                    ),
                    Text(
                      "Flavorly",
                      style: TextStyle(
                          color: Color.fromARGB(255, 39, 120, 42),
                          fontWeight: FontWeight.w600,
                          fontSize: 18),
                    ),
                    GestureDetector(
                      onTap: () {
                        showDialog(
                          context: context,
                          builder: (BuildContext context) {
                            return Dialog(
                              backgroundColor: Colors.transparent,
                              child: Container(
                                width: 300.0,
                                height: 140.0,
                                padding: EdgeInsets.all(16.0),
                                decoration: BoxDecoration(
                                  color: Colors.white,
                                  borderRadius: BorderRadius.only(
                                    topRight: Radius.circular(80),
                                    topLeft: Radius.circular(15),
                                    bottomRight: Radius.circular(15),
                                    bottomLeft: Radius.circular(15),
                                  ),
                                ),
                                child: Stack(
                                  clipBehavior: Clip.none,
                                  children: [
                                    Positioned(
                                      top: 5,
                                      left: 20,
                                      right: 20,
                                      child: Center(
                                        child: Text(
                                          "Flavorly!",
                                          style: TextStyle(
                                            fontSize: 18,
                                            fontWeight: FontWeight.w600,
                                          ),
                                        ),
                                      ),
                                    ),
                                    Positioned(
                                      top: -25,
                                      right: -15,
                                      child: GestureDetector(
                                        onTap: () {
                                          Navigator.pop(context);
                                        },
                                        child: Container(
                                            padding: EdgeInsets.all(8),
                                            decoration: BoxDecoration(
                                              borderRadius:
                                                  BorderRadius.circular(100),
                                              color: Color.fromARGB(
                                                  255, 39, 120, 42),
                                            ),
                                            child: Icon(
                                              Icons.close,
                                              color: Colors.white,
                                            )),
                                      ),
                                    ),
                                    Positioned(
                                      top: 40,
                                      left: 10,
                                      right: 10,
                                      child: Text(
                                        "It is tool where you can write any recipe and get the detials and the intersting things is to create new fusion as well",
                                        textAlign: TextAlign.justify,
                                        style: TextStyle(
                                          fontSize: 14,
                                          color: Colors.grey,
                                        ),
                                      ),
                                    ),
                                  ],
                                ),
                              ),
                            );
                          },
                        );
                      },
                      child: Icon(
                        Icons.info_outline,
                        color: Color.fromARGB(255, 39, 120, 42),
                      ),
                    ),
                  ],
                ),
              ),
              Positioned(
                top: 90,
                left: 25,
                right: 25,
                child: Container(
                  width: MediaQuery.of(context).size.width - 50,
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        isExpanded
                            ? des
                            : '${des.substring(0, 450)}${isExpanded ? "" : "..."}',
                        textAlign: TextAlign.justify,
                        style: TextStyle(
                            fontSize: 14, fontWeight: FontWeight.normal),
                      ),
                      GestureDetector(
                        onTap: () {
                          setState(() {
                            isExpanded = !isExpanded;
                          });
                        },
                        child: Text(
                          isExpanded ? 'View Less' : 'View More',
                          style: TextStyle(
                              color: Color.fromARGB(255, 39, 120, 42)),
                        ),
                      ),
                    ],
                  ),
                ),
              ),
              Positioned(
                right: 15,
                top: 25,
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.end,
                  children: [
                    Container(
                      width: 22,
                      height: 5,
                      decoration: BoxDecoration(
                          color: Color.fromARGB(255, 39, 120, 42),
                          borderRadius: BorderRadius.circular(100)),
                    ),
                    SizedBox(
                      height: 4,
                    ),
                    Container(
                      width: 34,
                      height: 4,
                      decoration: BoxDecoration(
                          color: Color.fromARGB(255, 39, 120, 42),
                          borderRadius: BorderRadius.circular(100)),
                    ),
                    SizedBox(
                      height: 4,
                    ),
                    Container(
                      width: 26,
                      height: 5,
                      decoration: BoxDecoration(
                          color: Color.fromARGB(255, 39, 120, 42),
                          borderRadius: BorderRadius.circular(100)),
                    )
                  ],
                ),
              ),
              Positioned(
                top: 65,
                child: Container(
                  width: MediaQuery.of(context).size.width,
                  child: Divider(
                    height: 1,
                  ),
                ),
              ),
              Positioned(
                top: MediaQuery.of(context).size.height * 0.55,
                child: Container(
                  height: 250,
                  padding: EdgeInsets.symmetric(
                    horizontal: 10,
                  ),
                  width: MediaQuery.of(context).size.width - 40,
                  margin: EdgeInsets.symmetric(horizontal: 20),
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      GestureDetector(
                        onTap: () {
                          setState(() {
                            isClicked1 = true;
                            isClicked2 = false;
                          });
                        },
                        child: Container(
                            height: 120,
                            width: MediaQuery.of(context).size.width * 0.35,
                            decoration: BoxDecoration(
                                border: Border.all(
                                    color: Colors.white,
                                    width: isClicked1 == true &&
                                            isClicked2 == false
                                        ? 2
                                        : 1),
                                borderRadius: BorderRadius.circular(15),
                                color:
                                    isClicked1 == false && isClicked2 == true ||
                                            (isClicked1 == false &&
                                                isClicked2 == false)
                                        ? Color.fromARGB(114, 255, 255, 255)
                                        : Color.fromARGB(255, 39, 120, 42)),
                            child: Column(
                              mainAxisAlignment: MainAxisAlignment.center,
                              children: [
                                Image.asset(
                                  'assets/images/fusion.png',
                                  height: 60,
                                ),
                                SizedBox(
                                  height: 5,
                                ),
                                Text(
                                  "Mix & Match With Flavor Fusion",
                                  style: TextStyle(
                                      color: isClicked1 == true &&
                                              isClicked2 == false
                                          ? Colors.white
                                          : Colors.black),
                                  textAlign: TextAlign.center,
                                ),
                              ],
                            )),
                      ),
                      GestureDetector(
                        onTap: () {
                          setState(() {
                            isClicked2 = true;
                            isClicked1 = false;
                          });
                        },
                        child: Container(
                            height: 120,
                            width: MediaQuery.of(context).size.width * 0.35,
                            decoration: BoxDecoration(
                                border: Border.all(
                                    color: Colors.white,
                                    width: isClicked2 == true &&
                                            isClicked1 == false
                                        ? 2
                                        : 1),
                                borderRadius: BorderRadius.circular(15),
                                color:
                                    isClicked2 == false && isClicked1 == true ||
                                            (isClicked1 == false &&
                                                isClicked2 == false)
                                        ? Color.fromARGB(114, 255, 255, 255)
                                        : Color.fromARGB(255, 39, 120, 42)),
                            child: Column(
                              mainAxisAlignment: MainAxisAlignment.center,
                              children: [
                                Image.asset(
                                  'assets/images/rebook.png',
                                  height: 60,
                                ),
                                SizedBox(
                                  height: 5,
                                ),
                                Text(
                                  "Unlock Recipe  Book",
                                  style: TextStyle(
                                      color: isClicked2 == true &&
                                              isClicked1 == false
                                          ? Colors.white
                                          : Colors.black),
                                  textAlign: TextAlign.center,
                                ),
                              ],
                            )),
                      ),
                    ],
                  ),
                ),
              ),
              Positioned(
                bottom: 15,
                child: Container(
                  height: 50,
                  padding: EdgeInsets.symmetric(
                    horizontal: 10,
                  ),
                  width: MediaQuery.of(context).size.width - 40,
                  margin: EdgeInsets.symmetric(horizontal: 20),
                  decoration: BoxDecoration(
                      borderRadius: BorderRadius.circular(15),
                      color: Colors.white),
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      Container(
                        width: MediaQuery.of(context).size.width - 120,
                        child: TextFormField(
                          focusNode: _focusNode,
                          decoration: InputDecoration(
                              border: InputBorder.none,
                              hintStyle: TextStyle(fontSize: 14),
                              hintText: 'What would you like to cook today?'),
                        ),
                      ),
                      Icon(
                        Icons.send,
                        color: Color.fromARGB(255, 39, 120, 42),
                      )
                    ],
                  ),
                ),
              )
            ],
          ),
        ),
      ),
    );
  }
}
