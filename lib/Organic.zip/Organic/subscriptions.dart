import 'package:flutter/material.dart';

class SubCription extends StatefulWidget {
  const SubCription({Key? key}) : super(key: key);

  @override
  State<SubCription> createState() => _SubCriptionState();
}

class _SubCriptionState extends State<SubCription> {
  List<String> data = [
    'Container 1',
    'Container 2',
    'Container 3',
    'Container 4',
    'Container 5',
    'Container 6',
    'Container 7',
    'Container 8',
    'Container 9',
    'Container 10'
  ];
  List<Color> colors = [
    Colors.red,
    Colors.amber,
    Colors.brown,
    Colors.blue,
    Colors.green,
    Colors.purple,
    Colors.teal,
    Colors.orange,
    Colors.indigo,
    Colors.pink
  ];
  int currentIndex = 0;

  final PageController _pageController = PageController(initialPage: 1);

  void moveToNext() {
    setState(() {
      currentIndex = (currentIndex + 1) % data.length;
      // Move the text in sync with the containers
      for (int i = 0; i < data.length; i++) {
        data[i] = 'Container ${(i + 4) % data.length + 1}';
      }
    });
  }

  void moveBackward() {
    setState(() {
      currentIndex = (currentIndex - 1) % data.length;
      // Move the text in sync with the containers
      for (int i = 0; i < data.length; i++) {
        data[i] = 'Container ${(i + 2) % data.length + 1}';
      }
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('ListView Builder Example'),
      ),
      body: Container(
        height: MediaQuery.of(context).size.height,
        width: MediaQuery.of(context).size.height,
        child: Stack(
          children: [
            Positioned(
              top: 20,
              left: 20,
              child: Container(
                child: IconButton(
                  icon: Icon(Icons.arrow_back),
                  onPressed: moveBackward,
                ),
              ),
            ),
            Positioned(
              top: 20,
              right: 20,
              child: Container(
                child: IconButton(
                  icon: Icon(Icons.arrow_forward),
                  onPressed: moveToNext,
                ),
              ),
            ),
            Positioned(
              top: 140,
              right: 20,
              child: Container(
                margin: EdgeInsets.only(top: 40),
                height: MediaQuery.of(context).size.height * 0.55,
                width: MediaQuery.of(context).size.height * 0.2,
                decoration: BoxDecoration(
                  borderRadius: BorderRadius.circular(20),
                  color: colors[currentIndex],
                ),
                child: Center(
                  child: Text(
                    data[currentIndex],
                    style: TextStyle(color: Colors.white),
                  ),
                ),
              ),
            ),
            Positioned(
              top: 140,
              left: 20,
              child: Container(
                margin: EdgeInsets.only(top: 40),
                height: MediaQuery.of(context).size.height * 0.55,
                width: MediaQuery.of(context).size.height * 0.2,
                decoration: BoxDecoration(
                  borderRadius: BorderRadius.circular(20),
                  color: colors[(currentIndex + 1) % data.length],
                ),
                child: Center(
                  child: Text(
                    data[(currentIndex + 1) % data.length],
                    style: TextStyle(color: Colors.white),
                  ),
                ),
              ),
            ),
            Positioned(
              top: 144,
              left: 60,
              right: 60,
              child: Container(
                height: MediaQuery.of(context).size.height * 0.6,
                width: MediaQuery.of(context).size.height,
                decoration: BoxDecoration(
                  borderRadius: BorderRadius.circular(20),
                  color: colors[(currentIndex + 2) % data.length],
                ),
                child: Center(
                  child: Text(
                    data[(currentIndex + 2) % data.length],
                    style: TextStyle(color: Colors.white),
                  ),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
