import 'package:flutter/material.dart';

class Cart extends StatefulWidget {
  const Cart({Key? key}) : super(key: key);

  @override
  State<Cart> createState() => _CartState();
}

class _CartState extends State<Cart> {
  List<Map<String, dynamic>> wheelItems = [
    {
      'title': 'Cow Milk',
      'price': '180',
      'imageUrl': 'assets/images/milk2.png',
      'quantity': 1,
    },
    {
      'title': 'Tomato',
      'price': '150',
      'imageUrl': 'assets/images/tmoto.png',
      'quantity': 1,
    },
    {
      'title': 'Goat Milk',
      'price': '160',
      'imageUrl': 'assets/images/gm.png',
      'quantity': 1,
    },
  ];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Color.fromARGB(212, 98, 194, 101),
      appBar: AppBar(
        elevation: 0,
        toolbarHeight: 60,
        backgroundColor: Color.fromARGB(212, 98, 194, 101),
        actions: [
          GestureDetector(
            child: Container(
                margin: EdgeInsets.all(10),
                padding: EdgeInsets.symmetric(horizontal: 10, vertical: 3),
                decoration: BoxDecoration(
                    borderRadius: BorderRadius.circular(1111),
                    color: Color.fromARGB(213, 255, 255, 255)),
                child: Row(
                  children: [
                    Text(
                      "CLear",
                      style: TextStyle(color: Colors.black),
                    ),
                    SizedBox(
                      width: 5,
                    ),
                    Icon(
                      Icons.delete,
                      color: Colors.black,
                    )
                  ],
                )),
          )
        ],
        leading: GestureDetector(
          onTap: () {
            Navigator.pop(context);
          },
          child: Container(
            child: Icon(
              Icons.arrow_back_ios,
              color: Color.fromARGB(194, 255, 255, 255),
            ),
          ),
        ),
        title: Text(
          "My Cart",
          style: TextStyle(
              fontSize: 22,
              color: Color.fromARGB(213, 255, 255, 255),
              fontWeight: FontWeight.w600),
        ),
      ),
      body: SingleChildScrollView(
        child: Column(
          children: [
            Container(
              padding: EdgeInsets.only(bottom: 10, top: 10),
              height: MediaQuery.of(context).size.height * 0.75,
              width: MediaQuery.of(context).size.width,
              decoration: BoxDecoration(
                color: Color.fromARGB(255, 245, 241, 241),
                borderRadius: BorderRadius.only(
                  bottomLeft: Radius.circular(40),
                  bottomRight: Radius.circular(40),
                ),
              ),
              child: ListView.builder(
                shrinkWrap: true,
                itemCount: wheelItems.length,
                itemBuilder: (BuildContext context, int index) {
                  final item = wheelItems[index];

                  return GestureDetector(
                    onTap: () {},
                    child: Container(
                      margin: EdgeInsets.only(bottom: 10, right: 10, left: 10),
                      height: 90,
                      color: Color.fromARGB(255, 255, 255, 255),
                      child: Stack(
                        clipBehavior: Clip.none,
                        children: [
                          Image.asset(
                            wheelItems[index]['imageUrl'],
                            height: 120,
                            width: 110,
                          ),
                          Positioned(
                            right: 0,
                            child: Container(
                              height: 30,
                              width: 60,
                              decoration: BoxDecoration(
                                  borderRadius: BorderRadius.only(
                                    bottomLeft: Radius.circular(60),
                                    // bottomRight: Radius.circular(60),
                                    // topLeft: Radius.circular(60),
                                    // topRight: Radius.circular(60),
                                  ),
                                  color: Color.fromARGB(194, 202, 245, 203)),
                              child: Center(child: Icon(Icons.close)),
                            ),
                          ),
                          Positioned(
                            left: 120,
                            child: Container(
                              width: MediaQuery.of(context).size.width - 150,
                              padding: const EdgeInsets.only(
                                top: 10,
                              ),
                              child: Column(
                                crossAxisAlignment: CrossAxisAlignment.start,
                                mainAxisAlignment: MainAxisAlignment.start,
                                children: [
                                  SizedBox(
                                    height: 10,
                                  ),
                                  Text(
                                    wheelItems[index]['title'],
                                    style: TextStyle(
                                        fontSize: 16,
                                        fontWeight: FontWeight.w500),
                                  ),
                                  Row(
                                    mainAxisAlignment:
                                        MainAxisAlignment.spaceBetween,
                                    children: [
                                      Row(
                                        mainAxisAlignment:
                                            MainAxisAlignment.spaceBetween,
                                        children: [
                                          Text(
                                              "Rs: " +
                                                  wheelItems[index]['price'],
                                              style: TextStyle(fontSize: 14)),
                                        ],
                                      ),
                                      Container(
                                        margin: EdgeInsets.only(top: 10),
                                        width: 80,
                                        padding:
                                            EdgeInsets.symmetric(horizontal: 5),
                                        decoration: BoxDecoration(
                                            color: Colors.white,
                                            borderRadius:
                                                BorderRadius.circular(10)),
                                        child: Row(
                                          mainAxisAlignment:
                                              MainAxisAlignment.spaceBetween,
                                          children: [
                                            Text(
                                              "-",
                                              style: TextStyle(fontSize: 29),
                                            ),
                                            Text(
                                              "1",
                                              style: TextStyle(fontSize: 25),
                                            ),
                                            Text(
                                              "+",
                                              style: TextStyle(fontSize: 22),
                                            ),
                                          ],
                                        ),
                                      ),
                                    ],
                                  )
                                ],
                              ),
                            ),
                          )
                        ],
                      ),
                    ),
                  );
                },
              ),
            ),
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 20),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  Row(
                    children: [
                      Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(
                            "Total",
                            style: TextStyle(
                                fontSize: 14,
                                color: Colors.white,
                                fontWeight: FontWeight.w600),
                          ),
                          Text(
                            "Amount",
                            style: TextStyle(
                                fontSize: 16,
                                color: Colors.white,
                                fontWeight: FontWeight.w600),
                          ),
                        ],
                      ),
                      SizedBox(
                        width: 10,
                      ),
                      Text(
                        "190",
                        style: TextStyle(
                            fontSize: 30,
                            color: Colors.white,
                            fontWeight: FontWeight.w600),
                      ),
                      Padding(
                        padding: EdgeInsets.only(top: 10),
                        child: Text(
                          "PKR",
                          style: TextStyle(
                              fontSize: 10,
                              color: Colors.white,
                              fontWeight: FontWeight.w600),
                        ),
                      ),
                    ],
                  ),
                  Container(
                    width: MediaQuery.of(context).size.width * 0.35,
                    decoration: BoxDecoration(
                        borderRadius: BorderRadius.circular(20),
                        color: Colors.white),
                    height: 50,
                    child: Center(
                      child: Text(
                        "Checkout",
                        style: TextStyle(
                            fontSize: 18,
                            color: Color.fromARGB(255, 39, 120, 42),
                            fontWeight: FontWeight.w600),
                      ),
                    ),
                  ),
                ],
              ),
            )
          ],
        ),
      ),
    );
  }
}
