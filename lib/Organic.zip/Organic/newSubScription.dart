import 'dart:html';

import 'package:flutter/material.dart';
import 'package:scroll_snap_list/scroll_snap_list.dart';

class quran5 extends StatefulWidget {
  const quran5({Key? key}) : super(key: key);

  @override
  State<quran5> createState() => _quran5State();
}

class _quran5State extends State<quran5> {
  final List<String> items = ['Item 1', 'Item 2', 'Item 3', 'Item 4', 'Item 5'];
  List clr = [
    Color.fromARGB(210, 142, 246, 145),
    Color.fromARGB(210, 94, 154, 96),
    Color.fromARGB(210, 142, 246, 145),
    Color.fromARGB(210, 80, 255, 86),
    Color.fromARGB(210, 142, 246, 145),
  ];
  List img = [
    "assets/images/milk2.png",
    "assets/images/milk.png",
    "assets/images/milk2.png",
    "assets/images/milk.png",
    "assets/images/milk2.png",
  ];
  int _focusedIndex = 0;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      // backgroundColor: Color.fromARGB(210, 142, 246, 145),
      appBar: AppBar(
        elevation: 0,
        toolbarHeight: 60,
        backgroundColor: Color.fromARGB(212, 98, 194, 101),
        leading: GestureDetector(
          onTap: () {
            Navigator.pop(context);
          },
          child: Container(
            padding: EdgeInsets.only(left: 5),
            child: Icon(
              Icons.arrow_back_ios,
              size: 30,
              color: Color.fromARGB(194, 255, 255, 255),
            ),
          ),
        ),
        title: Text(
          "All Subscriptions",
          style: TextStyle(
              fontSize: 24,
              color: Color.fromARGB(212, 0, 0, 0),
              fontWeight: FontWeight.w600),
        ),
      ),
      body: Column(
        children: <Widget>[
          SizedBox(
            height: 100,
          ),
          Container(
            height: MediaQuery.of(context).size.height * 0.6,
            child: ScrollSnapList(
              onItemFocus: (int index) {
                setState(() {
                  _focusedIndex = index;
                });
              },
              itemSize: 105,
              itemBuilder: (BuildContext context, int index) {
                return Container(
                  width: _focusedIndex == index ? 250 : 80,
                  decoration: BoxDecoration(
                    borderRadius: BorderRadius.circular(20),
                    color: clr[index],
                  ),
                  alignment: Alignment.center,
                  child: Column(
                    children: [
                      Text("Days/Week"),
                      Container(
                        width: 200,
                        height: 50,
                        color: Colors.white,
                      ),
                      Image.asset(img[index]),
                    ],
                  ),
                );
              },
              itemCount: clr.length,
              dynamicItemSize: true,
            ),
          ),
        ],
      ),
    );
  }
}
