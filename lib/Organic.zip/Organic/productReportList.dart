import 'package:flutter/material.dart';

class ProdductReportList extends StatefulWidget {
  const ProdductReportList({Key? key}) : super(key: key);

  @override
  State<ProdductReportList> createState() => _ProdductReportListState();
}

class _ProdductReportListState extends State<ProdductReportList> {
  List<Map<String, dynamic>> wheelItems = [
    {
      'title': 'Cow Milk',
      'imageUrl': 'assets/images/milk2.png',
    },
    {
      'title': 'Tomato',
      'imageUrl': 'assets/images/tmoto.png',
    },
    {
      'title': 'Goat Milk',
      'imageUrl': 'assets/images/gm.png',
    },
    {
      'title': 'Cow Milk',
      'imageUrl': 'assets/images/milk2.png',
    },
    {
      'title': 'Tomato',
      'imageUrl': 'assets/images/tmoto.png',
    },
    {
      'title': 'Goat Milk',
      'imageUrl': 'assets/images/gm.png',
    },
    {
      'title': 'Goat Milk',
      'imageUrl': 'assets/images/gm.png',
    },
    {
      'title': 'Cow Milk',
      'imageUrl': 'assets/images/milk2.png',
    },
    {
      'title': 'Tomato',
      'imageUrl': 'assets/images/tmoto.png',
    },
    {
      'title': 'Goat Milk',
      'imageUrl': 'assets/images/gm.png',
    },
  ];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Color.fromARGB(210, 142, 246, 145),
      appBar: AppBar(
        elevation: 0,
        toolbarHeight: 60,
        backgroundColor: Color.fromARGB(212, 98, 194, 101),
        leading: GestureDetector(
          onTap: () {
            Navigator.pop(context);
          },
          child: Container(
            padding: EdgeInsets.only(left: 5),
            child: Icon(
              Icons.arrow_back_ios,
              size: 30,
              color: Color.fromARGB(194, 255, 255, 255),
            ),
          ),
        ),
        title: Text(
          "Neutricion Report",
          style: TextStyle(
              fontSize: 24,
              color: Color.fromARGB(213, 255, 255, 255),
              fontWeight: FontWeight.w600),
        ),
      ),
      body: SingleChildScrollView(
        child: Column(
          children: [
            Container(
              padding: EdgeInsets.only(bottom: 75, top: 5),
              height: MediaQuery.of(context).size.height - 20,
              width: MediaQuery.of(context).size.width,
              decoration: BoxDecoration(
                borderRadius: BorderRadius.only(
                  bottomLeft: Radius.circular(40),
                  bottomRight: Radius.circular(40),
                ),
              ),
              child: ListView.builder(
                shrinkWrap: true,
                itemCount: wheelItems.length,
                itemBuilder: (BuildContext context, int index) {
                  final item = wheelItems[index];

                  return GestureDetector(
                    onTap: () {},
                    child: Container(
                      margin: EdgeInsets.only(
                          bottom: 10,
                          right: index % 2 == 1 ? 60 : 10,
                          // right: index % 2 == 1 ? 80 : 10,
                          left: index % 2 != 0 ? 10 : 60),
                      height: 80,
                      decoration: BoxDecoration(
                          color: Color.fromARGB(255, 255, 255, 255),
                          borderRadius: BorderRadius.circular(10)),
                      child: Stack(
                        clipBehavior: Clip.none,
                        children: [
                          Image.asset(
                            wheelItems[index]['imageUrl'],
                            height: 120,
                            width: 110,
                          ),
                          Positioned(
                            left: 100,
                            child: Container(
                              width: MediaQuery.of(context).size.width - 150,
                              padding: const EdgeInsets.only(
                                top: 10,
                              ),
                              child: Column(
                                crossAxisAlignment: CrossAxisAlignment.start,
                                mainAxisAlignment: MainAxisAlignment.start,
                                children: [
                                  SizedBox(
                                    height: 10,
                                  ),
                                  Text(
                                    wheelItems[index]['title'],
                                    style: TextStyle(
                                        fontSize: 16,
                                        fontWeight: FontWeight.w500),
                                  ),
                                  SizedBox(
                                    height: 5,
                                  ),
                                  Text(
                                    'Read neutricion report',
                                    style: TextStyle(
                                      fontSize: 14,
                                    ),
                                  ),
                                ],
                              ),
                            ),
                          ),
                          Positioned(
                            right: index % 2 == 1
                                ? -65
                                : MediaQuery.of(context).size.width - 65,
                            left: index % 2 == 0
                                ? -65
                                : MediaQuery.of(context).size.width - 65,
                            top: 10,
                            bottom: 10,
                            child: Container(
                              padding: EdgeInsets.all(20),
                              height: 50,
                              width: 60,
                              decoration: BoxDecoration(
                                borderRadius: BorderRadius.circular(10),
                              ),
                              child: Container(
                                height: 20,
                                width: 20,
                                decoration: BoxDecoration(
                                  color: index % 2 == 0
                                      ? Colors.white
                                      : Colors.transparent,
                                  border: Border.all(
                                    color: Colors.white,
                                  ),
                                  borderRadius: BorderRadius.circular(1000),
                                ),
                              ),
                            ),
                          )
                        ],
                      ),
                    ),
                  );
                },
              ),
            ),
          ],
        ),
      ),
    );
  }
}
