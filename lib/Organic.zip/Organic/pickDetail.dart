import 'package:flutter/material.dart';

class PickDetail extends StatefulWidget {
  const PickDetail({super.key});

  @override
  State<PickDetail> createState() => _PickDetailState();
}

class _PickDetailState extends State<PickDetail>
    with SingleTickerProviderStateMixin {
  late AnimationController _controller;
  late Animation<double> _animation;

  int quantity = 1;

  @override
  void initState() {
    super.initState();
    _controller = AnimationController(
      vsync: this,
      duration: Duration(milliseconds: 300),
    );
    _animation = Tween<double>(begin: 1, end: 1.3).animate(
      CurvedAnimation(
        parent: _controller,
        curve: Curves.easeInOut,
      ),
    );
  }

  void _animateIcon() {
    _controller.forward(from: 0);
  }

  void incrementQuantity() {
    setState(() {
      quantity++;
      _animateIcon();
    });
  }

  void decrementQuantity() {
    if (quantity > 1) {
      setState(() {
        quantity--;
        _animateIcon();
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        actions: [
          GestureDetector(
            onTap: () {
              showDialog(
                context: context,
                builder: (BuildContext context) {
                  return abc();
                },
              );
            },
            child: Container(
                margin: EdgeInsets.all(10),
                padding: EdgeInsets.symmetric(horizontal: 10, vertical: 3),
                decoration: BoxDecoration(
                    borderRadius: BorderRadius.circular(7),
                    color: Colors.white),
                child: Row(
                  children: [
                    Text(
                      "Daily",
                      style: TextStyle(fontSize: 10),
                    ),
                    SizedBox(
                      width: 5,
                    ),
                    // ElTooltip(
                    //   child: Icon(Icons.info_outline),
                    //   content: Text('This is a tooltip'),
                    // ),
                    //      GestureDetector(
                    // onTap: () {
                    //   // Show tooltip on tap
                    //   final RenderBox overlay = Overlay.of(context).context.findRenderObject() as RenderBox;
                    //   final tooltip = Tooltip(
                    //     message: 'Mean Daily Subscription',
                    //     child: Container(),
                    //   );
                    //   tooltip.show(overlay);
                    //   // Delay for a moment and then hide the tooltip
                    //   Future.delayed(Duration(seconds: 2), () {
                    //     tooltip.hide();
                    //   });
                    // },
                    // child: Icon(
                    //   Icons.info,
                    //   size: 18,
                    //   color: Color.fromARGB(214, 37, 115, 151),
                    // ),
                    // ),
                  ],
                )),
          )
        ],
        leading: Container(
          margin: EdgeInsets.all(10),
          decoration: BoxDecoration(
              borderRadius: BorderRadius.circular(1000000),
              color: Color.fromARGB(255, 135, 201, 237)),
          child: IconButton(
              onPressed: () {
                Navigator.pop(context);
              },
              icon: Icon(
                Icons.arrow_back_ios,
                size: 20,
                color: Colors.white,
              )),
        ),
        backgroundColor: Color.fromARGB(214, 37, 115, 151),
      ),
      body: SingleChildScrollView(
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          mainAxisAlignment: MainAxisAlignment.start,
          children: [
            Container(
                height: 100,
                width: MediaQuery.of(context).size.width,
                decoration: BoxDecoration(
                    color: Color.fromARGB(214, 37, 115, 151),
                    borderRadius:
                        BorderRadius.only(bottomRight: Radius.circular(60))),
                child: Stack(
                  clipBehavior: Clip.none,
                  children: [
                    Positioned(
                      right: 10,
                      bottom: 50,
                      child: Container(
                        height: 10,
                        width: 10,
                        decoration: BoxDecoration(
                            borderRadius: BorderRadius.circular(100),
                            color: Color.fromARGB(242, 255, 255, 255)),
                      ),
                    ),
                    Positioned(
                      right: 110,
                      top: 20,
                      child: Transform.rotate(
                        angle: 10,
                        child: Container(
                          height: 14,
                          width: 14,
                          decoration: BoxDecoration(
                              borderRadius: BorderRadius.circular(100),
                              color: Color.fromARGB(242, 255, 255, 255)),
                        ),
                      ),
                    ),
                    Positioned(
                      right: 90,
                      top: 0,
                      child: Container(
                        height: 5,
                        width: 5,
                        decoration: BoxDecoration(
                            borderRadius: BorderRadius.circular(100),
                            color: Color.fromARGB(242, 255, 255, 255)),
                      ),
                    ),
                    Positioned(
                      right: -10,
                      bottom: -40,
                      child: Container(
                        height: 150,
                        width: 150,
                        padding: EdgeInsets.all(5),
                        child: Image.asset("assets/images/milk2.png"),
                      ),
                    ),
                    Positioned(
                      left: 15,
                      top: 30,
                      child: Text(
                        "Pure",
                        style: TextStyle(
                            fontSize: 22,
                            fontWeight: FontWeight.w600,
                            color: Colors.white),
                      ),
                    ),
                    Positioned(
                      left: 15,
                      top: 55,
                      child: Text(
                        "Cow Milk",
                        style: TextStyle(
                            fontSize: 22,
                            fontWeight: FontWeight.w600,
                            color: Colors.white),
                      ),
                    ),
                  ],
                )),
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 20),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                mainAxisAlignment: MainAxisAlignment.start,
                children: [
                  Text(
                    "Price",
                    style: TextStyle(
                      fontSize: 12,
                    ),
                  ),
                  Text(
                    "PKR: 190/L ",
                    style: TextStyle(fontSize: 16, fontWeight: FontWeight.w600),
                  ),
                  SizedBox(
                    height: 8,
                  ),
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(
                            "Freshness",
                            style: TextStyle(
                              fontSize: 12,
                            ),
                          ),
                          Text(
                            "100%",
                            style: TextStyle(
                                fontSize: 16, fontWeight: FontWeight.w600),
                          ),
                        ],
                      ),
                      Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(
                            "For Health",
                            style: TextStyle(
                              fontSize: 12,
                            ),
                          ),
                          Text(
                            "100%",
                            style: TextStyle(
                                fontSize: 16, fontWeight: FontWeight.w600),
                          ),
                        ],
                      ),
                    ],
                  ),
                  SizedBox(
                    height: 10,
                  ),
                  // Text(
                  //   "Neutricion Value",
                  //   style: TextStyle(fontSize: 16, fontWeight: FontWeight.w600),
                  // ),
                  Text(
                    "Some thext about 3 to 4 line what kinds of value contain some thext about 3 to 4 line what kinds of value contain some thext about 3 to 4 line what kinds of value contain Some thext about 3 to 4 line what kinds of value contain some thext about 3 to 4 line what kinds of value contain some thext about 3 to 4 line what kinds of value contain",
                    textAlign: TextAlign.justify,
                    style:
                        TextStyle(fontSize: 12, fontWeight: FontWeight.normal),
                  ),
                  SizedBox(
                    height: 20,
                  ),
                ],
              ),
            ),
            Align(
              alignment: Alignment.topRight,
              child: Container(
                width: MediaQuery.of(context).size.width,
                decoration:
                    BoxDecoration(color: Color.fromARGB(110, 170, 225, 255)),
                child: Stack(
                  clipBehavior: Clip.none,
                  children: [
                    Positioned(
                      top: -23,
                      left: MediaQuery.of(context).size.width * 0.35,
                      child: Container(
                        width: 60,
                        height: 45,
                        decoration: BoxDecoration(
                            borderRadius: BorderRadius.circular(100),
                            border: Border.all(
                                width: 2,
                                color: Color.fromARGB(110, 170, 225, 255)),
                            // borderRadius: BorderRadius.only(
                            //   bottomLeft: Radius.circular(100),
                            //   bottomRight: Radius.circular(100),
                            //   topLeft: Radius.circular(10),
                            //   topRight: Radius.circular(10),
                            // ),
                            color: Colors.white),
                        child: Column(
                          children: [
                            Text(
                              "190",
                              style: TextStyle(
                                  color: Colors.black,
                                  fontSize: 18,
                                  fontWeight: FontWeight.w600),
                            ),
                            Align(
                              alignment: Alignment.topRight,
                              child: Padding(
                                padding: const EdgeInsets.only(right: 15),
                                child: Text(
                                  "PKR",
                                  style: TextStyle(
                                    color: Colors.black,
                                    fontSize: 10,
                                  ),
                                ),
                              ),
                            ),
                          ],
                        ),
                      ),
                    ),
                    Row(
                      mainAxisAlignment: MainAxisAlignment.spaceAround,
                      children: [
                        Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Text(
                              "Total",
                              style: TextStyle(
                                fontSize: 12,
                              ),
                            ),
                            Text(
                              "Amount",
                              style: TextStyle(
                                  fontSize: 16, fontWeight: FontWeight.w600),
                            ),
                          ],
                        ),
                        GestureDetector(
                          onTap: () {
                            FocusScope.of(context).unfocus();
                          },
                          child: Container(
                            width: 90,
                            height: 35,
                            margin: EdgeInsets.symmetric(vertical: 10),
                            decoration: BoxDecoration(
                                borderRadius: BorderRadius.circular(100),
                                border:
                                    Border.all(width: 2, color: Colors.white),
                                color: Colors.white),
                            child: Row(
                              mainAxisAlignment: MainAxisAlignment.spaceAround,
                              children: [
                                GestureDetector(
                                  onTap: () {
                                    incrementQuantity();
                                  },
                                  child: ScaleTransition(
                                    scale: _animation,
                                    child: Icon(
                                      Icons.add,
                                      size: 18,
                                      color: Colors.black,
                                    ),
                                  ),
                                ),
                                Text(
                                  "$quantity",
                                  style: TextStyle(
                                    fontSize: 18,
                                    fontWeight: FontWeight.bold,
                                    color: Colors.black,
                                  ),
                                ),
                                GestureDetector(
                                  onTap: () {
                                    decrementQuantity();
                                  },
                                  child: ScaleTransition(
                                    scale: _animation,
                                    child: Icon(
                                      Icons.remove,
                                      size: 18,
                                      color: Colors.black,
                                    ),
                                  ),
                                ),
                              ],
                            ),
                          ),
                        ),
                      ],
                    ),
                  ],
                ),
              ),
            ),
            SizedBox(
              height: 15,
            ),
            Center(
              child: GestureDetector(
                onTap: () {},
                child: Container(
                  height: 40,
                  width: MediaQuery.of(context).size.width * 0.9,
                  decoration: BoxDecoration(
                    // border: Border.all(color: Color.fromARGB(214, 37, 115, 151),
                    // ),
                    borderRadius: BorderRadiusDirectional.circular(15),
                    color: Colors.white,

                    boxShadow: [
                      BoxShadow(
                        color: Color.fromARGB(255, 135, 201, 237),
                        blurRadius: 4,
                        offset: Offset(4, 1), // Shadow position
                      ),
                    ],
                  ),
                  child: Row(
                    children: [
                      GestureDetector(
                        onTap: () {},
                        child: Container(
                          height: 40,
                          width: MediaQuery.of(context).size.width * 0.5,
                          decoration: BoxDecoration(
                            boxShadow: [
                              BoxShadow(
                                color: Color.fromARGB(255, 135, 201, 237),
                                blurRadius: 4,
                                offset: Offset(0, 4), // Shadow position
                              ),
                            ],
                            borderRadius: BorderRadiusDirectional.circular(15),
                            color: Color.fromARGB(214, 37, 115, 151),
                          ),
                          child: Stack(
                            children: [
                              Container(
                                height: 30,
                                width: 30,
                                margin: EdgeInsets.all(5),
                                decoration: BoxDecoration(
                                  borderRadius:
                                      BorderRadiusDirectional.circular(10),
                                  color: Colors.white,
                                ),
                                child: Icon(
                                  Icons.shopping_cart,
                                  size: 18,
                                  color: Color.fromARGB(214, 37, 115, 151),
                                ),
                              ),
                              Positioned(
                                  left: 38,
                                  top: 10,
                                  child: Text(
                                    "Add to Cart",
                                    style: TextStyle(
                                        color: Colors.white,
                                        fontSize: 14,
                                        fontWeight: FontWeight.w600),
                                  ))
                            ],
                          ),
                        ),
                      ),
                      SizedBox(
                        width: MediaQuery.of(context).size.width * 0.5 / 8,
                      ),
                      Text(
                        "Buy Now",
                        style: TextStyle(
                            color: Colors.black,
                            fontSize: 14,
                            fontWeight: FontWeight.w600),
                      )
                    ],
                  ),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class abc extends StatefulWidget {
  const abc({super.key});

  @override
  State<abc> createState() => _abcState();
}

class _abcState extends State<abc> {
  List<String> selectedDays = [];
  List<String> selectedTimes = [];

  @override
  Widget build(BuildContext context) {
    return Dialog(
      child: Container(
        width: 300.0,
        height: 400.0,
        padding: EdgeInsets.all(16.0),
        decoration: BoxDecoration(
          color: Colors.white,
          borderRadius: BorderRadius.circular(20),
        ),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          crossAxisAlignment: CrossAxisAlignment.center,
          children: [
            Text(
              "Subscription",
              style: TextStyle(
                fontSize: 18,
                fontWeight: FontWeight.w600,
              ),
            ),
            SizedBox(height: 8.0),
            Text(
              "No need to order daily. Choose days and times for delivery.",
              textAlign: TextAlign.center,
              style: TextStyle(
                fontSize: 14,
                color: Colors.grey,
              ),
            ),
            SizedBox(height: 16.0),
            Container(
              height: 40.0,
              child: ListView.builder(
                scrollDirection: Axis.horizontal,
                itemCount: 7, // Days of the week
                itemBuilder: (context, index) {
                  String day = getDayName(index);
                  bool isSelected = selectedDays.contains(day);

                  return GestureDetector(
                    onTap: () {
                      setState(() {
                        if (isSelected) {
                          selectedDays.remove(day);
                        } else {
                          selectedDays.add(day);
                        }
                      });
                    },
                    child: Container(
                      margin: EdgeInsets.symmetric(horizontal: 8.0),
                      padding: EdgeInsets.all(8.0),
                      decoration: BoxDecoration(
                        color: isSelected ? Colors.blue : Colors.grey,
                        borderRadius: BorderRadius.circular(8),
                      ),
                      child: Text(
                        day,
                        style: TextStyle(
                          color: isSelected ? Colors.white : Colors.black,
                        ),
                      ),
                    ),
                  );
                },
              ),
            ),
            SizedBox(height: 16.0),
            if (selectedDays.isNotEmpty)
              Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  Text("Delivery times: "),
                  for (int i = 0; i < selectedDays.length; i++)
                    Padding(
                      padding: EdgeInsets.symmetric(horizontal: 8.0),
                      child: DropdownButton<String>(
                        value:
                            selectedTimes.length > i ? selectedTimes[i] : null,
                        items: ["Morning", "Afternoon", "Evening"]
                            .map((time) => DropdownMenuItem(
                                  value: time,
                                  child: Text(time),
                                ))
                            .toList(),
                        onChanged: (selectedTime) {
                          setState(() {
                            if (selectedTimes.length <= i) {
                              selectedTimes.add(selectedTime!);
                            } else {
                              selectedTimes[i] = selectedTime!;
                            }
                          });
                        },
                      ),
                    ),
                ],
              ),
            SizedBox(height: 16.0),
            ElevatedButton(
              onPressed: () {
                // Add your subscription logic here
                Navigator.of(context).pop(); // Close the dialog
              },
              child: Text('Subscribe'),
            ),
            SizedBox(height: 8.0),
            ElevatedButton(
              onPressed: () {
                Navigator.of(context).pop(); // Close the dialog
              },
              style: ElevatedButton.styleFrom(
                primary: Colors.grey, // Use a different color if needed
              ),
              child: Text('Close'),
            ),
          ],
        ),
      ),
    );
  }

  String getDayName(int index) {
    List<String> days = ["Mon", "Tue", "Wed", "Thu", "Fri", "Sat", "Sun"];
    return days[index];
  }
}
