import 'package:flutter/material.dart';
import 'package:flutter_application_1/Organic/productReportList.dart';
import 'package:flutter_application_1/Organic/subscriptions.dart';
import 'package:material_dialogs/material_dialogs.dart';

Drawer MyDrawer(BuildContext context) {
  return Drawer(
      backgroundColor: Colors.transparent,
      elevation: 0,
      width: MediaQuery.of(context).size.width * 0.6,
      child: Container(
        margin: EdgeInsets.only(top: 35),
        decoration: BoxDecoration(
            borderRadius: BorderRadius.only(
              topRight: Radius.circular(35),
              bottomRight: Radius.circular(35),
            ),
            color: Color.fromARGB(212, 98, 194, 101)),
        child: Stack(
          clipBehavior: Clip.none,
          children: [
            Positioned(
              right: -80,
              top: 20,
              child: Container(
                height: 220,
                width: 290,
                padding: EdgeInsets.symmetric(horizontal: 15, vertical: 10),
                decoration: BoxDecoration(
                    borderRadius: BorderRadius.only(
                      topRight: Radius.circular(20),
                      bottomRight: Radius.circular(20),
                    ),
                    color: Color.fromARGB(255, 202, 245, 203)),
                child: Stack(
                  children: [
                    Positioned(
                      top: 10,
                      left: 0,
                      child: Container(
                        height: 90,
                        width: 90,
                        padding: const EdgeInsets.all(6),
                        decoration: BoxDecoration(
                            color: Color.fromARGB(255, 255, 255, 255),
                            borderRadius: BorderRadius.circular(1000)),
                        child: ClipRRect(
                          borderRadius: BorderRadius.circular(2000),
                          // child: Image.asset(
                          //   "assets/images/main_logo.jpeg",
                          // ),
                        ),
                      ),
                    ),
                    Positioned(
                      top: 120,
                      left: 15,
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          const Text(
                            "Khalis",
                            style: TextStyle(
                                color: Color.fromARGB(212, 98, 194, 101),
                                fontSize: 28,
                                fontWeight: FontWeight.bold),
                          ),
                          const Text(
                            "The Organic Market",
                            style: TextStyle(
                                fontSize: 16,
                                color: Color.fromARGB(211, 0, 0, 0)),
                          ),
                        ],
                      ),
                    ),
                    Positioned(
                      right: -10,
                      top: -10,
                      child: GestureDetector(
                        onTap: () {
                          Navigator.pop(context);
                        },
                        child: Container(
                          margin: const EdgeInsets.only(top: 10, right: 10),
                          width: 40,
                          height: 40,
                          child: const Icon(
                            Icons.close_outlined,
                            color: Color.fromARGB(255, 0, 0, 0),
                          ),
                        ),
                      ),
                    )
                  ],
                ),
              ),
            ),
            Positioned(
              right: -80,
              top: 246,
              child: Container(
                  height: MediaQuery.of(context).size.height - 300,
                  width: 240,
                  padding: EdgeInsets.symmetric(horizontal: 15, vertical: 10),
                  decoration: BoxDecoration(
                      borderRadius: BorderRadius.only(
                        topRight: Radius.circular(20),
                        bottomRight: Radius.circular(20),
                        bottomLeft: Radius.circular(20),
                        topLeft: Radius.circular(20),
                      ),
                      color: Color.fromARGB(255, 202, 245, 203))),
            ),
            Positioned(
              left: 0,
              top: 245,
              child: Column(children: [
                SizedBox(
                  height: 15,
                ),
                GestureDetector(
                    onTap: () {
                      Navigator.pop(context);
                      Navigator.push(
                          context,
                          MaterialPageRoute(
                              builder: (context) => SubCription()));
                    },
                    child:
                        Menues(context, Icons.subscriptions, "Subscription")),
                SizedBox(
                  height: 5,
                ),
                GestureDetector(
                    onTap: () {
                      Navigator.pop(context);
                      Navigator.push(
                          context,
                          MaterialPageRoute(
                              builder: (context) => ProdductReportList()));
                    },
                    child: Menues(context, Icons.report, "Neutricion Report")),
                SizedBox(
                  height: 5,
                ),
                Menues(context, Icons.history, "Order History"),
                SizedBox(
                  height: 5,
                ),
                Menues(context, Icons.storage, "About Khalis"),
                SizedBox(
                  height: 5,
                ),
                Menues(context, Icons.discount, "Offers"),
                SizedBox(
                  height: 5,
                ),
                Menues(context, Icons.logout, "Logout"),
                SizedBox(
                  height: 5,
                ),
              ]),
            ),
          ],
        ),
      ));
}

Container Menues(BuildContext context, IconData i, String t) {
  return Container(
      width: 220,
      padding: const EdgeInsets.symmetric(vertical: 20, horizontal: 15),
      color: Color.fromARGB(32, 255, 255, 255),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          Icon(
            i,
            size: 25,
            color: Color.fromARGB(255, 0, 0, 0),
          ),
          Container(
            padding: EdgeInsets.only(left: 30),
            width: 165,
            child: Text(
              t,
              style: TextStyle(
                  color: Colors.black,
                  fontSize: 16,
                  fontWeight: FontWeight.w500),
            ),
          ),
        ],
      ));
}
